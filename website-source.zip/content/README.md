# Publishing a new research issue

1. Work on your research privately in ChatGPT. Verify and approve its evidence and wording.
2. Save one Markdown document in `content/issues/`, copying `_TEMPLATE.md`.
3. Keep `status: draft` while reviewing; draft files never create public articles.
4. When ready, set `status: published`, enter the actual publication date and source URLs, and submit the change to a review pull request.
5. Merge the pull request only after approval. The GitHub Pages workflow builds a new article, updates the public research index, `feed.xml`, and `sitemap.xml`, and deploys automatically.

Note: the existing illustrative working note 001 is a static experimental draft, and is deliberately excluded from the public sitemap and search index until its evidence is approved. The subscription form is also disabled until a working compliant provider is connected.
