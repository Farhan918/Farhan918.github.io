#!/usr/bin/env python3
"""Build a vintage research publication from Markdown. No JS server required.
Publish only explicitly approved `status: published` notes.
"""
from pathlib import Path
from datetime import date, datetime, timezone
from html import escape
from urllib.parse import urlparse
import json, re, shutil, sys
from xml.etree.ElementTree import Element, SubElement, tostring
import yaml, mistune
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / '_site'
SITE = 'https://farhan918.github.io'
PUBLIC = ['/', '/work/', '/work/workflow-redesign/', '/work/control-gateway/', '/about/', '/research/']
md = mistune.create_markdown(escape=True, plugins=['table', 'url', 'strikethrough'])


def parse_note(path):
    raw = path.read_text(encoding='utf-8')
    m = re.match(r'\A---\s*\n(.*?)\n---\s*\n(.*)\Z', raw, re.S)
    if not m: raise ValueError(f'{path}: missing YAML front matter')
    meta = yaml.safe_load(m.group(1))
    if not isinstance(meta, dict): raise ValueError(f'{path}: invalid metadata')
    if meta.get('status') != 'published': return None
    for key in ['title','slug','summary','answer','date','sources']:
        if not meta.get(key): raise ValueError(f'{path}: published note missing {key}')
    slug = str(meta['slug'])
    if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', slug): raise ValueError(f'{path}: invalid slug')
    if slug == 'the-part-nobody-demos': raise ValueError('Reserved draft article slug')
    dt = meta['date'].isoformat() if isinstance(meta['date'],date) else str(meta['date'])
    date.fromisoformat(dt)
    meta['date'] = dt
    for src in meta['sources']:
        if not isinstance(src,dict) or not src.get('title') or urlparse(str(src.get('url',''))).scheme not in ('http','https'):
            raise ValueError(f'{path}: all sources need a title and valid HTTP(S) URL')
        if 'example.com' in src['url']: raise ValueError(f'{path}: replace example sources before publishing')
    if len(m.group(2).strip()) < 250: raise ValueError(f'{path}: article body is too short')
    meta['body'] = md(m.group(2).strip())
    return meta


def add_meta(soup, name, value, prop=False):
    key='property' if prop else 'name'
    tag=soup.head.find('meta', attrs={key:name})
    if tag is None: tag=soup.new_tag('meta');tag[key]=name;soup.head.append(tag)
    tag['content']=value


def render_article(note, template):
    s=BeautifulSoup(template, 'html.parser')
    title=str(note['title']); summary=str(note['summary']);slug=str(note['slug']);url=f'{SITE}/research/{slug}/'
    s.title.string = f'{title} | The Hidden Work'
    add_meta(s,'description',summary)
    add_meta(s,'robots','index,follow')
    add_meta(s,'og:title',f'{title} | The Hidden Work',True)
    add_meta(s,'og:description',summary,True)
    add_meta(s,'og:type','article',True)
    add_meta(s,'og:url',url,True)
    add_meta(s,'article:published_time',note['date'],True)
    canonical=s.head.find('link',rel='canonical')
    if canonical:canonical['href']=url
    else:s.head.append(s.new_tag('link',rel='canonical',href=url))
    data={'@context':'https://schema.org','@type':'BlogPosting',
          'headline':title,'description':summary,'datePublished':note['date'],
          'author':{'@type':'Person','name':'Farhan Abdullah','url':SITE+'/'},
          'publisher':{'@type':'Person','name':'Farhan Abdullah'},
          'mainEntityOfPage':url,
          'citation':[str(x['url']) for x in note['sources']]}
    script=s.new_tag('script',type='application/ld+json');script.string=json.dumps(data,ensure_ascii=False);s.head.append(script)
    # Do not carry the first article's calculator JS into future articles.
    for obsolete in s.body.find_all('script'):
        obsolete.decompose()
    main=s.find('main',id='content')
    main.clear()
    sources=''.join('<li><a href="'+escape(str(x['url']),quote=True)+'" rel="noopener noreferrer" target="_blank">'+escape(str(x['title']))+'</a></li>' for x in note['sources'])
    body=f"""<article class="paperpage" id="article">
      <div class="kicker">The Hidden Work / Independent research</div>
      <div class="article-main prose">
        <p class="cover-brow">Published {escape(note['date'])} · Farhan Abdullah</p>
        <h1>{escape(title)}</h1>
        <p class="lede">{escape(summary)}</p>
        <hr/>
        <p><strong>Short answer:</strong> {escape(str(note['answer']))}</p>
        {note['body']}
        <h2>Sources and further reading</h2>
        <ol>{sources}</ol>
        <p><em>Corrections or evidence to challenge this work are welcome.</em></p>
        <p><a href="../index.html#archive">Return to the research archive</a> · <a href="../../index.html">About the author</a></p>
      </div>
      <div class="folio"><span>The Hidden Work / Farhan Abdullah</span><span>Research article</span></div>
    </article>"""
    fragment=BeautifulSoup(body,'html.parser')
    main.append(fragment)
    return str(s)


def insert_archive(notes):
    p=OUT/'research/index.html'
    s=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser')
    target=s.select_one('#archive .contents')
    if target is None: raise RuntimeError('Research archive missing')
    for i,n in reversed(list(enumerate(notes, start=2))):
        link=BeautifulSoup(f'<a href="{escape(n["slug"],quote=True)}/index.html"><span class="number">{i:02d}.</span><div><strong>{escape(str(n["title"]))}</strong><small>{escape(str(n["summary"]))}</small></div><em>{escape(str(n["date"]))}</em></a>','html.parser')
        target.insert(0,link)
    p.write_text(str(s),encoding='utf-8')


def write_sitemap(notes):
    paths=PUBLIC + [f'/research/{x["slug"]}/' for x in notes]
    root=Element('urlset', xmlns='http://www.sitemaps.org/schemas/sitemap/0.9')
    for path in paths:
        el=SubElement(root,'url');SubElement(el,'loc').text=SITE+path
    (OUT/'sitemap.xml').write_bytes(b'<?xml version="1.0" encoding="UTF-8"?>\n'+tostring(root,encoding='utf-8'))
    (OUT/'robots.txt').write_text(f'User-agent: *\nAllow: /\nSitemap: {SITE}/sitemap.xml\n')
    (OUT/'.nojekyll').touch()


def write_feed(notes):
    rss=Element('rss',version='2.0'); channel=SubElement(rss,'channel')
    for k,v in [('title','The Hidden Work'),('link',SITE+'/research/'),('description','Independent research on technology, operations and overlooked decisions')]:
        SubElement(channel,k).text=v
    for n in notes:
        item=SubElement(channel,'item')
        for k,v in [('title',n['title']),('link',f'{SITE}/research/{n["slug"]}/'),('guid',f'{SITE}/research/{n["slug"]}/'),('description',n['summary'])]:SubElement(item,k).text=str(v)
        d=datetime.combine(date.fromisoformat(n['date']),datetime.min.time(),tzinfo=timezone.utc)
        SubElement(item,'pubDate').text=d.strftime('%a, %d %b %Y %H:%M:%S +0000')
    (OUT/'feed.xml').write_bytes(b'<?xml version="1.0" encoding="UTF-8"?>\n'+tostring(rss,encoding='utf-8'))


def build():
    if OUT.exists(): shutil.rmtree(OUT)
    OUT.mkdir()
    (OUT/'index.html').write_bytes((ROOT/'index.html').read_bytes())
    for name in ['about','research','work']:
        shutil.copytree(ROOT/name,OUT/name)
    notes=[]
    for path in sorted((ROOT/'content/issues').glob('*.md')):
        if path.name.startswith('_'):continue
        n=parse_note(path)
        if n is not None:notes.append(n)
    notes.sort(key=lambda n:(n['date'],n['slug']),reverse=True)
    template=(ROOT/'research/the-part-nobody-demos/index.html').read_text(encoding='utf-8')
    for note in notes:
        path=OUT/'research'/note['slug']/'index.html'
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(render_article(note,template),encoding='utf-8')
    insert_archive(notes)
    write_sitemap(notes)
    write_feed(notes)
    print(f'Built {len(notes)} published research article(s) in {OUT}')

if __name__=='__main__':
    try:build()
    except Exception as e:print(f'ERROR: {e}',file=sys.stderr);sys.exit(1)
